/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Grade;

/**
 *
 * @author gul
 */
public class GradeBo {
    
    public void addGrade(Grade grade){
        BoUtill.getInstance().gradeDao.addGrade(grade);
    
    }
    public void deleteGrade(int gradeid){
        BoUtill.getInstance().gradeDao.deleteGrade(gradeid);
    }
    public void updateGrade(Grade grade){
        BoUtill.getInstance().gradeDao.updateGrade(grade);
    }
    public List<Grade> getAllGrades(){
        return BoUtill.getInstance().gradeDao.getAllGrades();
    }
    public Grade getGradeById(int gradeid){
        return BoUtill.getInstance().gradeDao.getGradeById(gradeid);
    }
    
    
}
