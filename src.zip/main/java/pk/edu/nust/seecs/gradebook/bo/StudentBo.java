/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Student;

/**
 *
 * @author gul
 */
public class StudentBo {
    public void addStudent(Student student){
        BoUtill.getInstance().studentDao.addStudent(student);
    }
    public void deleteStudent(int studentid){
        BoUtill.getInstance().studentDao.deleteStudent(studentid);
    }
    public void updateStudent(Student student){
        BoUtill.getInstance().studentDao.updateStudent(student);
    }
    public List<Student> getAllStudents(){
        return BoUtill.getInstance().studentDao.getAllStudents();
    }
    public Student getStudentById(int studentid){
    
        return BoUtill.getInstance().studentDao.getStudentById(studentid);
    }
    
}
