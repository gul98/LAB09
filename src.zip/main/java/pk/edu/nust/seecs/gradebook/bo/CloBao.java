/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/**
 *
 * @author gul
 */
public class CloBao {
    
    
    public void addClo(Clo clo){
        BoUtill.getInstance().cloDao.addClo(clo);
            
    }
    
    public void deleteClo(int cloid){
        BoUtill.getInstance().cloDao.deleteClo(cloid);
    }
    
    public void updateClo(Clo clo){
        BoUtill.getInstance().cloDao.updateClo(clo);
    }
    
    public List<Clo> getAllClos(){
       return BoUtill.getInstance().cloDao.getAllClos();
    }
    
    public Clo getCloById(int cloid){
    
        return BoUtill.getInstance().cloDao.getCloById(cloid);
    }
    
    
    
    
    
    
}
