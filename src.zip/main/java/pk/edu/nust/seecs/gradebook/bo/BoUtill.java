/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.*;

/**
 *
 * @author gul
 */
public class BoUtill {
    
    public CloDao cloDao;
    
    public ContentDao contentDao;
    
    public CourseDao courseDao;
    
    public GradeDao gradeDao;
    
    public StudentDao studentDao;
    
    public TeacherDao teacherDao;
    
    private static BoUtill instance;
    
    
    public BoUtill(){
        cloDao= new CloDao();
        
        contentDao= new ContentDao();
        
        courseDao= new CourseDao();
        
        gradeDao=new GradeDao();
        
        studentDao= new StudentDao();
        
        teacherDao= new TeacherDao();
        
    }
    
    public static BoUtill getInstance(){
        
        if(instance== null)
            instance= new BoUtill();
        return instance;         
        
    }
    
    
}
