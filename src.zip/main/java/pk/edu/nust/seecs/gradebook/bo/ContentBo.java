/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Content;

/**
 *
 * @author gul
 */
public class ContentBo {
    
    
     public void addContent(Content content){
         BoUtill.getInstance().contentDao.addContent(content);
     }
      public void deleteContent(int contentid){
          BoUtill.getInstance().contentDao.deleteContent(contentid);
      }
      public void updateContent(Content content){
          BoUtill.getInstance().contentDao.updateContent(content);
      
      }
      public List<Content> getAllContents(){
          return BoUtill.getInstance().contentDao.getAllContents();
      }
      public Content getContentById(int contentid){
          return BoUtill.getInstance().contentDao.getContentById(contentid);
      }
      
    
}
