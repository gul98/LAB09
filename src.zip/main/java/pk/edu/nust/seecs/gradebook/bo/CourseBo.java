/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Course;

/**
 *
 * @author gul
 */
public class CourseBo {
    
    public void addCourse(Course course){
        BoUtill.getInstance().courseDao.addCourse(course);
    }
    public void deleteCourse(int courseid) {
        BoUtill.getInstance().courseDao.deleteCourse(courseid);
    }
    public void updateCourse(Course course){
        BoUtill.getInstance().courseDao.updateCourse(course);
    }
    public List<Course> getAllCourses(){
        return BoUtill.getInstance().courseDao.getAllCourses();
    
    }
    public Course getCourseById(int courseid){
        return BoUtill.getInstance().courseDao.getCourseById(courseid);
    }
    
    
}
