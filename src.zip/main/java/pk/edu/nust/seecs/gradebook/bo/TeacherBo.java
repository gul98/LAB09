/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

/**
 *
 * @author gul
 */
public class TeacherBo {
    
    public void addTeacher(Teacher teacher){
        BoUtill.getInstance().teacherDao.addTeacher(teacher);
    }
    public void deleteTeacher(int teacherid){
        BoUtill.getInstance().teacherDao.deleteTeacher(teacherid);
    }
    public void updateTeacher(Teacher teacher){
        BoUtill.getInstance().teacherDao.updateTeacher(teacher);
    }
    public List<Teacher> getAllTeachers(){
       return BoUtill.getInstance().teacherDao.getAllTeachers();
    }
    public Teacher getTeacherById(int teacherid){
        return BoUtill.getInstance().teacherDao.getTeacherById(teacherid);
    }
    
    
}
