package pk.edu.nust.seecs.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pk.edu.nust.seecs.gradebook.bo.*;
import pk.edu.nust.seecs.gradebook.entity.*;
import pk.edu.nust.seecs.gradebook.entity.DoSomething;
 

/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("classpath:/META_INF/spring-config.xml");
//        DoSomething ds = (DoSomething)appContext.getBean("doSomething");
//        System.out.println(ds.toString());
        setUpCourses(appContext);
        
//        Clo clo = new Clo();
//        clo.setName("CLO 4");
//        clo.setDescription("Bus kar dou or nahi");
//        clo.setPlo("10021");
//        
////        CloBao bo= (CloBao) appContext.getBean("business_clo");
////        bo.addClo(clo);
//        CloDao clodao= new CloDao();
//        clodao.addClo(clo);
    
//        CloDao clodao = new CloDao();
//        System.out.print("hello");
//        // Add new clo
//        Clo clo = new Clo();
//        clo.setName("CLO 1");
//        clo.setDescription("Design efficient solutions for algorithmic problems");
//        clo.setPlo("2");
//        clodao.addClo(clo);
//
//        clodao.updateClo(clo);

        // Delete an existing clo
        //dao.deleteClo(1);

        // Get all clos
//        for (Clo iter : clodao.getAllClos()) {
//            System.out.println(iter);
//        }
//
//        // Get clo by id
//        System.out.println(clodao.getCloById(1));

        
    }
    
    
    private static void addCourses(ApplicationContext context){
    CourseBo bo=(CourseBo) context.getBean("business_course");
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
    Date date= new Date();
    Date endDate= new Date();
    try{
    date= fmt.parse("2017-12-13");
    endDate=fmt.parse("2018-3-13");
    }
    catch(ParseException e){
        e.printStackTrace();
    }
    Course course= new Course("test",date,endDate,4);
    Teacher teacher= new Teacher();
    TeacherBo tbo= (TeacherBo) context.getBean("business_teacher");
    
    teacher=tbo.getTeacherById(4);
        
    course.setTeacher(teacher);
    bo.addCourse(course);
        
    }
    
   
    private static void addClos(ApplicationContext context){
         Clo clo = new Clo();
        clo.setName("CLO 4");
        clo.setDescription("Bus kar dou or nahi");
        clo.setPlo("10021");
        
       CloBao bo= (CloBao) context.getBean("business_clo");
       bo.addClo(clo);
        
    }
    
    private static void addGrades(ApplicationContext context){
        
    
    }
    
    private static void addTeachers(ApplicationContext context){
    
        
    }
    private static void addStudents(ApplicationContext context){
        StudentBo bo= (StudentBo) context.getBean("business_student");
        CourseBo cbo= (CourseBo) context.getBean("business_course");
        Course course= cbo.getCourseById(5);
        Set<Course> set= new HashSet<Course>(Arrays.asList(course));
        Student student= new Student();
        student.setName("gullu");
        student.setCourses(set);
        bo.addStudent(student);
    }
    
    private static void setUpCourses(ApplicationContext context){
        addStudents(context);
        
    }

}