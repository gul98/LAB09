/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/**
 *
 * @author gul
 */
public class CloBaoTest {
    
    public CloBaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addClo method, of class CloBao.
     */
 

    /**
     * Test of getCloById method, of class CloBao.
     */
    @org.junit.Test
    public void testGetCloById() {
        System.out.println("getCloById");
        int cloid = 0;
        CloBao instance = new CloBao();
        Clo expResult = null;
        Clo result = instance.getCloById(2);
        assertEquals("10021", result.getPlo());
        // TODO review the generated test code and remove the default call to fail.
       
    }
    
}
